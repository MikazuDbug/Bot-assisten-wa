
module.exports = {
  geminiApiKey: "AIzaSyBYilRdtAwvxdJfLgflsMNER5H9TbPcTrA"
};
