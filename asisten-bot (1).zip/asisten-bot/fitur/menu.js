
const fs = require('fs');
const path = './media/banner.jpg';

async function kirimMenuUtama(sock, jid) {
  const banner = fs.readFileSync(path);

  await sock.sendMessage(jid, {
    image: banner,
    caption: `🤖 *Asisten Ibu Hamil*

Selamat datang! Pilih fitur yang tersedia:

👶 *tanya: <pertanyaan>* – Tanya apapun seputar kehamilan
📅 *reminder* – Cek pengingat harian
🌟 *premium* – Cek status premium & upgrade
💬 *menu* – Tampilkan menu ini lagi

🧘 Gambar motivasi harian dikirim otomatis setiap pagi
🙏 Doa & dukungan spiritual juga tersedia tiap hari

🛠 Developer: Gilang Irchas
📞 WA: https://wa.me/6283135290294`,
    footer: 'Asisten Ibu Hamil - Teman Setia Ibu Mengandung'
  });
}

module.exports = { kirimMenuUtama };
