
const fs = require('fs');
const path = './database/users.json';

function loadUsers() {
  if (!fs.existsSync(path)) fs.writeFileSync(path, '[]');
  return JSON.parse(fs.readFileSync(path));
}

function saveUsers(users) {
  fs.writeFileSync(path, JSON.stringify(users, null, 2));
}

async function handleUser(msg, sock) {
  const from = msg.key.remoteJid;
  let users = loadUsers();
  let user = users.find(u => u.jid === from);

  if (!user) {
    const newUser = {
      jid: from,
      nama: msg.pushName || 'Ibu Hamil',
      premium: false,
      daftar: new Date().toISOString()
    };
    users.push(newUser);
    saveUsers(users);

    await sock.sendMessage(from, {
      text: `👋 Halo *${newUser.nama}*, kamu berhasil terdaftar di *Asisten Ibu Hamil*! Ketik *menu* untuk mulai. 🤰`
    });
  }
}

module.exports = { handleUser };
