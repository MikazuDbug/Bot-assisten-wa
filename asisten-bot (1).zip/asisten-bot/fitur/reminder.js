
async function kirimReminderHarian(sock, jid) {
  const pesan = `📅 *Pengingat Harian*

✅ Minum vitamin & cukup istirahat
✅ Periksa jadwal kontrol ke dokter
✅ Catat gerakan bayi jika sudah terasa
✅ Perbanyak ibadah & pikiran positif 🧘‍♀️

🤱 Semangat Ibu! Hari ini adalah anugerah 💖`;

  await sock.sendMessage(jid, { text: pesan });
}

module.exports = { kirimReminderHarian };
