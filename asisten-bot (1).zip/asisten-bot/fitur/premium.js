
const fs = require('fs');
const path = './database/users.json';

function loadUsers() {
  if (!fs.existsSync(path)) fs.writeFileSync(path, '[]');
  return JSON.parse(fs.readFileSync(path));
}

async function cekStatus(sock, jid) {
  const users = loadUsers(); 
  const user = users.find(u => u.jid === jid);

  if (user?.premium) {
    await sock.sendMessage(jid, { text: '🌟 Kamu adalah pengguna *Premium*! Terima kasih!' });
  } else {
    await sock.sendMessage(jid, { text: '🚫 Kamu belum menjadi pengguna *Premium*. Kirim bukti pembayaran ke admin untuk aktivasi.' });
  }
}

module.exports = { cekStatus };
